# Keep JNI entry points used by native methods.
-keepclasseswithmembernames class * {
    native <methods>;
}
