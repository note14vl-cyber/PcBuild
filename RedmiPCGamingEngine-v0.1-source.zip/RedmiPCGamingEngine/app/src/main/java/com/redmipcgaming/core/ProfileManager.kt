package com.redmipcgaming.core

import android.content.Context

class ProfileManager(context: Context) {
    private val prefs = context.getSharedPreferences("engine_profiles", Context.MODE_PRIVATE)

    fun getProfile(): String = prefs.getString(KEY_PROFILE, "Balanced") ?: "Balanced"

    fun setProfile(profile: String) {
        prefs.edit().putString(KEY_PROFILE, profile).apply()
    }

    fun nextProfile(profiles: List<String>): String {
        require(profiles.isNotEmpty())
        val current = getProfile()
        val next = profiles[(profiles.indexOf(current).takeIf { it >= 0 }?.plus(1) ?: 0) % profiles.size]
        setProfile(next)
        return next
    }

    fun saveGameFolder(uri: String) {
        prefs.edit().putString(KEY_GAME_FOLDER, uri).apply()
    }

    fun getGameFolder(): String? = prefs.getString(KEY_GAME_FOLDER, null)

    companion object {
        private const val KEY_PROFILE = "profile"
        private const val KEY_GAME_FOLDER = "game_folder_uri"
    }
}
