package com.redmipcgaming.hardware

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.PowerManager
import android.os.Process
import android.os.SystemClock
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class DeviceMonitor(context: Context) {
    private val appContext = context.applicationContext
    private val activityManager =
        appContext.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private val powerManager =
        appContext.getSystemService(Context.POWER_SERVICE) as PowerManager

    private val executor: ScheduledExecutorService =
        Executors.newSingleThreadScheduledExecutor()
    private val running = AtomicBoolean(false)

    @Volatile private var previousCpu = Process.getElapsedCpuTime()
    @Volatile private var previousWall = SystemClock.elapsedRealtime()

    fun sample(): HardwareSnapshot {
        val memory = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memory)

        val total = memory.totalMem / MB
        val available = memory.availMem / MB
        val used = (total - available).coerceAtLeast(0)

        val nowCpu = Process.getElapsedCpuTime()
        val nowWall = SystemClock.elapsedRealtime()
        val cpuDelta = (nowCpu - previousCpu).coerceAtLeast(0)
        val wallDelta = (nowWall - previousWall).coerceAtLeast(1)

        val cpu = (cpuDelta.toFloat() / wallDelta * 100f).coerceIn(0f, 100f)
        previousCpu = nowCpu
        previousWall = nowWall

        return HardwareSnapshot(
            totalRamMb = total,
            usedRamMb = used,
            availableRamMb = available,
            appCpuPercent = cpu,
            thermalStatus = thermalStatus(),
            thermalHeadroom = thermalHeadroom(),
            lowMemory = memory.lowMemory,
            timestamp = System.currentTimeMillis()
        )
    }

    fun startMonitoring(intervalMs: Long = 2000, callback: (HardwareSnapshot) -> Unit) {
        require(intervalMs >= 1000) { "Sampling interval must be at least 1000 ms" }
        if (!running.compareAndSet(false, true)) return

        executor.scheduleWithFixedDelay({
            if (running.get()) {
                runCatching { callback(sample()) }
            }
        }, 0, intervalMs, TimeUnit.MILLISECONDS)
    }

    fun stopMonitoring() {
        running.set(false)
        executor.shutdownNow()
    }

    private fun thermalStatus(): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return "UNAVAILABLE"
        return when (powerManager.currentThermalStatus) {
            PowerManager.THERMAL_STATUS_NONE -> "NORMAL"
            PowerManager.THERMAL_STATUS_LIGHT -> "LIGHT"
            PowerManager.THERMAL_STATUS_MODERATE -> "MODERATE"
            PowerManager.THERMAL_STATUS_SEVERE -> "SEVERE"
            PowerManager.THERMAL_STATUS_CRITICAL -> "CRITICAL"
            PowerManager.THERMAL_STATUS_EMERGENCY -> "EMERGENCY"
            PowerManager.THERMAL_STATUS_SHUTDOWN -> "SHUTDOWN"
            else -> "UNKNOWN"
        }
    }

    private fun thermalHeadroom(): Float? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return null
        return runCatching {
            powerManager.getThermalHeadroom(0).takeIf { it.isFinite() && it >= 0f }
        }.getOrNull()
    }

    companion object {
        private const val MB = 1024L * 1024L
    }
}
