package com.redmipcgaming

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import com.redmipcgaming.core.EngineCore
import com.redmipcgaming.core.ProfileManager
import com.redmipcgaming.hardware.DeviceMonitor
import com.redmipcgaming.hardware.HardwareSnapshot
import com.redmipcgaming.runtime.RuntimeManager
import com.redmipcgaming.thermal.ThermalAdvisor

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var monitorText: TextView
    private lateinit var runtimeText: TextView
    private lateinit var folderText: TextView
    private lateinit var profileText: TextView

    private lateinit var monitor: DeviceMonitor
    private val handler = Handler(Looper.getMainLooper())
    private var monitoring = false

    private val folderPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
            if (uri != null) {
                val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                try {
                    contentResolver.takePersistableUriPermission(uri, flags)
                    ProfileManager(this).saveGameFolder(uri.toString())
                    folderText.text = "Папка игры:\n$uri"
                } catch (e: Exception) {
                    toast("Не удалось сохранить доступ: ${e.message}")
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        EngineCore.initialize(this)
        monitor = DeviceMonitor(this)
        buildUi()
        loadSavedFolder()
        updateRuntimeStatus()
        updateProfile()
        startMonitoring()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(20))
            setBackgroundColor(0xFF10141D.toInt())
        }

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        content.addView(label("REDMI PC GAMING ENGINE", 25f, 0xFFFFFFFF.toInt(), true))
        content.addView(label("Independent Android gaming platform • v${BuildConfig.VERSION_NAME}", 13f, 0xFF9EACC0.toInt()))
        content.addView(label("DEVICE TARGET", 13f, 0xFF65D6A5.toInt(), true))
        content.addView(label("Helio G99 Ultra  •  Mali-G57 MC2  •  6 GB RAM", 14f, 0xFFE7EDF5.toInt()))

        content.addView(section("HARDWARE MONITOR"))
        monitorText = label("Сбор показателей…", 14f, 0xFFE7EDF5.toInt())
        content.addView(monitorText)
        content.addView(actionButton("ОБНОВИТЬ ПОКАЗАТЕЛИ") { renderSnapshot(monitor.sample()) })

        content.addView(section("THERMAL ADVISOR"))
        content.addView(label("Советник оценивает системный thermal status. Он не меняет частоты и не отключает защиту Android.", 13f, 0xFF9EACC0.toInt()))
        content.addView(actionButton("ПОЛУЧИТЬ РЕКОМЕНДАЦИЮ") {
            val snapshot = monitor.sample()
            toast(ThermalAdvisor.recommend(snapshot))
        })

        content.addView(section("RUNTIME MANAGER"))
        runtimeText = label("Поиск совместимой среды…", 14f, 0xFFE7EDF5.toInt())
        content.addView(runtimeText)
        content.addView(actionButton("НАЙТИ УСТАНОВЛЕННУЮ СРЕДУ") { updateRuntimeStatus() })
        content.addView(actionButton("ОТКРЫТЬ СРЕДУ") { launchRuntime() })

        content.addView(section("GAME LIBRARY"))
        folderText = label("Папка игры не выбрана", 12f, 0xFFB8C4D6.toInt())
        content.addView(folderText)
        content.addView(actionButton("ВЫБРАТЬ ПАПКУ ИГРЫ") { folderPicker.launch(null) })

        content.addView(section("GAME PROFILE"))
        profileText = label("", 14f, 0xFFE7EDF5.toInt())
        content.addView(profileText)
        content.addView(actionButton("ПРОФИЛЬ: BALANCED") {
            val profiles = listOf("Balanced", "Cool", "Performance")
            val current = ProfileManager(this).nextProfile(profiles)
            updateProfile()
            toast("Выбран профиль: $current")
        })

        content.addView(section("NATIVE CORE"))
        content.addView(label(
            runCatching { EngineCore.nativeSummary() }.getOrElse { "Native core unavailable: ${it.message}" },
            13f, 0xFF9EACC0.toInt()
        ))

        content.addView(label("Без Root • Без разгона • Android управляет системной термозащитой", 11f, 0xFF738198.toInt()))
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun startMonitoring() {
        if (monitoring) return
        monitoring = true
        monitor.startMonitoring(2000) { snapshot ->
            handler.post {
                if (!isFinishing && !isDestroyed) renderSnapshot(snapshot)
            }
        }
    }

    private fun renderSnapshot(s: HardwareSnapshot) {
        monitorText.text = buildString {
            append("RAM total: ${s.totalRamMb} MB\n")
            append("RAM available: ${s.availableRamMb} MB\n")
            append("RAM used (system estimate): ${s.usedRamMb} MB\n")
            append("App CPU: ${"%.1f".format(s.appCpuPercent)}%\n")
            append("Thermal: ${s.thermalStatus}\n")
            append("Thermal headroom: ${s.thermalHeadroom?.let { "%.2f".format(it) } ?: "недоступно"}\n")
            append("Low memory flag: ${s.lowMemory}")
        }
    }

    private fun updateRuntimeStatus() {
        val runtimes = RuntimeManager(this).findRuntimes()
        runtimeText.text = if (runtimes.isEmpty()) {
            "Совместимые среды не обнаружены.\nУстанови выбранную среду отдельно."
        } else {
            runtimes.joinToString("\n") { "${it.label} (${it.packageName})" }
        }
    }

    private fun launchRuntime() {
        val runtimes = RuntimeManager(this).findRuntimes()
        if (runtimes.isEmpty()) {
            toast("Совместимая среда не найдена")
            return
        }
        val chosen = runtimes.first()
        val intent = packageManager.getLaunchIntentForPackage(chosen.packageName)
        if (intent != null) startActivity(intent) else toast("Не удалось открыть ${chosen.label}")
    }

    private fun loadSavedFolder() {
        val uri = ProfileManager(this).getGameFolder()
        folderText.text = if (uri.isNullOrBlank()) "Папка игры не выбрана" else "Папка игры:\n$uri"
    }

    private fun updateProfile() {
        val profile = ProfileManager(this).getProfile()
        profileText.text = "PC Building Simulator 1\nПрофиль: $profile\nРекомендуемый старт: 640×480, низкие настройки."
    }

    private fun section(text: String) =
        label(text, 15f, 0xFF65D6A5.toInt(), true).apply {
            setPadding(0, dp(20), 0, dp(4))
        }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            setPadding(dp(2), dp(7), dp(2), dp(7))
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun actionButton(text: String, action: () -> Unit) =
        Button(this).apply {
            this.text = text
            isAllCaps = false
            setOnClickListener { action() }
        }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        if (::monitor.isInitialized) monitor.stopMonitoring()
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
