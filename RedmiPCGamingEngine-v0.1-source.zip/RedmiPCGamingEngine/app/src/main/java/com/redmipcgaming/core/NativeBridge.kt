package com.redmipcgaming.core

internal object NativeBridge {
    init {
        System.loadLibrary("redmi_engine")
    }

    external fun nativeSummary(): String

    fun summary(): String = nativeSummary()
}
