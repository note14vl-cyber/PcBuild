package com.redmipcgaming.hardware

data class HardwareSnapshot(
    val totalRamMb: Long,
    val usedRamMb: Long,
    val availableRamMb: Long,
    val appCpuPercent: Float,
    val thermalStatus: String,
    val thermalHeadroom: Float?,
    val lowMemory: Boolean,
    val timestamp: Long
)
