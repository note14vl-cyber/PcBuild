package com.redmipcgaming.core

import android.content.Context

object EngineCore {
    @Volatile private var initialized = false

    fun initialize(context: Context) {
        if (initialized) return
        synchronized(this) {
            if (!initialized) {
                // Initialize platform services here as modules are added.
                initialized = true
            }
        }
    }

    fun nativeSummary(): String = try {
        NativeBridge.summary()
    } catch (e: UnsatisfiedLinkError) {
        "Native core not loaded: ${e.message}"
    }
}
