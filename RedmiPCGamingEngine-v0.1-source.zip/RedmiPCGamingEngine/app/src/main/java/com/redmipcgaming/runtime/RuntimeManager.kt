package com.redmipcgaming.runtime

import android.content.Context
import android.content.Intent

data class RuntimeInfo(val label: String, val packageName: String)

class RuntimeManager(private val context: Context) {
    fun findRuntimes(): List<RuntimeInfo> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return context.packageManager.queryIntentActivities(intent, 0)
            .mapNotNull { resolve ->
                val packageName = resolve.activityInfo?.packageName ?: return@mapNotNull null
                val label = resolve.loadLabel(context.packageManager)?.toString() ?: packageName
                val searchable = "$label $packageName".lowercase()
                if (searchable.contains("winlator") ||
                    searchable.contains("gamehub") ||
                    searchable.contains("mobox")) {
                    RuntimeInfo(label, packageName)
                } else null
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }
}
