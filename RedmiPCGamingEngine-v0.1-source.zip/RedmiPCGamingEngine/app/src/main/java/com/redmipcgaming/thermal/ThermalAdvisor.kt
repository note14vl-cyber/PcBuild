package com.redmipcgaming.thermal

import com.redmipcgaming.hardware.HardwareSnapshot

object ThermalAdvisor {
    fun recommend(snapshot: HardwareSnapshot): String {
        return when (snapshot.thermalStatus) {
            "SEVERE", "CRITICAL", "EMERGENCY", "SHUTDOWN" ->
                "Телефон сильно нагрет. Сделай паузу и дай ему остыть. Системную термозащиту не отключай."
            "MODERATE" ->
                "Нагрев повышен. Для длительной игры попробуй снизить разрешение или ограничить FPS."
            "LIGHT" ->
                "Небольшой нагрев. Продолжай наблюдение; не повышай графику без теста."
            "NORMAL" ->
                if (snapshot.availableRamMb < 700) {
                    "Температура нормальная, но доступной RAM мало. Закрой ненужные приложения."
                } else {
                    "Системный thermal status нормальный. Можно продолжать тестирование."
                }
            else ->
                "Данные о нагреве недоступны. Следи за температурой и поведением телефона."
        }
    }
}
