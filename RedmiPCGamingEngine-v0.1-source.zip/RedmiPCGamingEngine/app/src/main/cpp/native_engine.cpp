#include <jni.h>
#include <unistd.h>
#include <sstream>
#include <string>
#include <thread>

extern "C"
JNIEXPORT jstring JNICALL
Java_com_redmipcgaming_core_NativeBridge_nativeSummary(
    JNIEnv* env,
    jobject /* thiz */
) {
    std::ostringstream out;
    const long onlineCores = sysconf(_SC_NPROCESSORS_ONLN);
    const long pageSize = sysconf(_SC_PAGESIZE);

    out << "Native core: loaded\n";
    out << "ABI: arm64-v8a\n";
    out << "Online CPU cores: " << onlineCores << "\n";
    out << "Memory page size: " << pageSize << " bytes\n";
    out << "C++ hardware concurrency: "
        << std::thread::hardware_concurrency();

    const std::string result = out.str();
    return env->NewStringUTF(result.c_str());
}
